 <?php
 
 /*
 
 Project Name : search data from database base on search funtion
 Description:Create a database and table in the databe add feild like id,name,email,age,country,candidate_id
 and include the database config file. 
 validation the data according to you here, Validation on the number
 
 
 */
 
 
 
 
 ?>
 
 <?php 
        
             require_once('config.php'); // database config file
             
        	if(isset($_GET['search']))
        	{
        		$filtervalues = $_GET['search'];
        		
        		if (is_numeric($filtervalues)){
        		    
        		$query = "SELECT * FROM search_table WHERE CONCAT(id,name,email,age,country,candidate_id) LIKE '%$filtervalues%' ";
        		$query_run = mysqli_query($link, $query);
        
        
        	    }else
                	{
        	             echo '<script>alert("No record found")</script>';
        	        }
        	
        	}
?>

<!doctype html>
<html lang="en">
<head>
<!-- Required meta tags -->
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;300;400;700;900&display=swap" rel="stylesheet" />
<title>WHMIS QUIZ</title>

<style>
html, body {overflow-x: hidden;}
body{color: #212326;background: #4fc0e8;font-family: 'Lato', sans-serif;margin:0;}
h1, h2, h3, h4, h5, h6, p {color: #212326;}
img {max-width:100%;}
button{outline:none !important;}
* {box-sizing:border-box;}
.text-center {text-align:center;}

.center_box {
    max-width: 480px;
    margin: 46px auto;
    padding: 50px 0;
}

.main_box {
    background-color: #fff;
    padding: 40px;
    border-radius: 10px;
    margin-top: 60px;
}
.main_box h1 {
    margin: 20px 0 0;
    font-size: 22px;
    font-weight: 600;
}
.main_box p {
    font-size: 16px;
    margin-bottom: 20px;
}
.get_btn {
    width: 100%;
    font-family: inherit;
    font-weight: 600;
    font-size: 18px;
    line-height: 24px;
    color: #fff;
    background-color: #a0d468;
    border: 1px solid #a0d468;
    border-radius: 5px;
    padding: 10px;
    cursor: pointer;
}
.table-border {
    /*border:1px solid #red;*/
    
    margin:2%;
}
#login-button {
    background-color: #4CAF50;
    border: none;
    color: white;
    padding: 15px 32px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    margin-top: 20px;
}

input.search_box {
    padding: 16px;
}

.input-group.mb-3 {
    padding: 10px;
}
.title {
    font-weight: 600;
}
table.table.table-border {
    border: 2px solid #000;
    padding: 10px;
    max-width: 100%;
}

</style>
</head>
<body>
<section class="">
	<div class="text-center center_box">
		<img src="/Quiz/assets/images/jobadder.svg" alt="" />
		<div class="main_box">
		
		
    <div class="container">
        <div class="row">
           
                    
        <div class="card-body">
            <div class="row"> 
            <div class="title">Search Data from the data base ex: Search candidate id</div>
                <div class="col-md-7">

                    <form action="" method="GET">
                        <div class="input-group mb-3">
                            <input type="text" name="search"  class="search_box" required value="<?php if(isset($_GET['search'])){echo $_GET['search']; } ?>" class="form-control" placeholder="Search candidate id">
                            <button type="submit" id="login-button">Search</button>
                        </div>
                    </form>

                </div>
            </div>
        </div>
              

        <div class="card-body">
            <table class="table table-border">
            <thead class="table_row">
                <tr class="table_row1">
                    <th>S.no</th>
                    <th>name</th>
                    <th>email</th>
                    <th>age</th>
                    <th>country</th>
                    <th>candidate id</th>
                </tr>
            </thead>
             <tbody>
                 <?php
             		if(mysqli_num_rows($query_run) > 0)
        		{
        			foreach($query_run as $row)
        			{
        			?>
        			<tr>
        			<td><?= $row['id']; ?></td>
        			<td><?= $row['name']; ?></td>
        			<td><?= $row['email']; ?></td>
        			<td><?= $row['age']; ?></td>
        			<td><?= $row['country']; ?></td>
        			<td><?= $row['candidate_id']; ?></td>
        			</tr>
        			<?php
        			}
        		}
        		
        	?>
         </tbody>
            </table>
        </div>
           
        </div>
    </div>

 <!--<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/css/bootstrap.min.css" rel="stylesheet">-->
  <!--<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.1/dist/js/bootstrap.bundle.min.js"></script>-->

    
   
		</div>
	</div>
</section>
</body>
</html>
